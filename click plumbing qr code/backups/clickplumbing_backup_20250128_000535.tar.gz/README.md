# Click Plumbing Admin Portal

A comprehensive web application for managing plumbing machines, parts, and user access.

## Features

1. Machine and Part Maintenance Tracking
   - Machine management with customer details and location
   - Parts tracking with QR code support
   - Warranty tracking

2. Health Monitoring
   - Real-time machine operational data
   - Sensor data tracking (flow, pressure, temperature)

3. User Management
   - Role-based access control (Admin, Engineer, Account Manager)
   - Machine assignment capabilities

4. Audit Logging
   - Comprehensive action tracking

## Setup

1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   ```

4. Initialize the database:
   ```bash
   flask db upgrade
   ```

5. Run the application:
   ```bash
   flask run
   ```

## Default Admin Credentials

- Email: admin@admin.com
- Password: admin123

**Important**: Change these credentials immediately after first login.

## Security Notice

This is an administrative portal. Please ensure:
1. Strong passwords are used
2. Regular security audits are performed
3. Access is restricted to authorized personnel only
